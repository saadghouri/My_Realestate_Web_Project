realestateApp.controller('mainController', function ($scope, $http, $location, $i18next, $rootScope) {
    console.log('start');
    $rootScope.isSecured = false;
    $rootScope.appInitFlag = false;
    
    $scope.searchData = {};
    $scope.loginData = {};
    $scope.isLoggedin = false;
    $rootScope.isLoggedin = false;

    $scope.init = function () {
        $scope.loadRecentProperty();
        $scope.loadLocation();
        $http({
            method: 'POST',
            url: get_base_url() + '/validate_user',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    console.log(data);
                    if (!data.success) {
                        $scope.systemErrors = false;
                        $scope.message = false;
                    } else {
                        $scope.userData = data.success.data;
                        $scope.welcomeMessage = data.success.message;
                        $rootScope.welcomeMessage = data.success.message;
                        $scope.systemErrors = false;
                        $scope.isLoggedin = true;
                        $rootScope.isLoggedin = true;
                    }
                });
        $rootScope.appInitFlag = true;
    };
    
    $scope.loadRecentProperty = function () {
        console.log($location.path());
        console.log('main_init');
        $http({
            method: 'POST',
            url: get_base_url() + '/property/recent',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    console.log(data);
                    if (!data.success) {
                        $location.path('/home');
                    } else {
                        $scope.recentProperty = data.success.data.recent_property;
                        $rootScope.recentProperty = data.success.data.recent_property;
                        $scope.systemErrors = false;
                    }
                });
        $rootScope.appInitFlag = true;
    };    
    
    $scope.loadLocation = function () {
        $('#login_btn').button('loading');
        $scope.isDisabled = true;
        $http({
            method: 'POST',
            url: get_base_url() + '/property/location',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        
                    } else {
                        $scope.countries = data.success.data;
                    }
                })
                .error(function (data, status) {
                    if (status == 0) {
                        $scope.systemErrors = "Connectivity problem while logging in. Please try again.";
                        $scope.message = false;
                        $scope.isDisabled = false;
                    }
                });
    };
    
    $scope.searchProperty = function () {
        $('#login_btn').button('loading');
        $scope.isDisabled = true;
        $scope.searchData.state = $('#state').val();
        $http({
            method: 'POST',
            url: get_base_url() + '/property/search',
            data: $.param($scope.searchData),
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    console.log(data);
                    if (!data.success) {
                        alert('No Result Found');
                    } else {
                        $scope.searchResult = data.success.data.search_property;
                        $rootScope.searchResult = data.success.data.search_property;
                        $location.path('/search/1');
                    }
                })
                .error(function (data, status) {
                    if (status == 0) {
                        $scope.systemErrors = "Connectivity problem while logging in. Please try again.";
                        $scope.message = false;
                        $scope.isDisabled = false;
                    }
                });
    };

    $scope.redirect_link = function (link) {
        $location.path('' + link);
    };
});

realestateApp.controller('resetPassController', function ($scope, $http, $i18next, $sce, $location, $rootScope) {
    $rootScope.act_btn_isHidden = true;
    $rootScope.bottom_menu_isHidden = true;
    $scope.rpData = {};
    $scope.rpData.building_id = $rootScope.building_id;
    $scope.cvData = {code: 0, email: getUrlParameter('email')};
    $scope.cvData.building_id = $rootScope.building_id;
    $scope.isDisabled = false;
    $scope.resetForm = true;
    $scope.newPassword = false;
    $scope.npData = {};
    $scope.npData.building_id = $rootScope.building_id;
    $scope.submitrpForm = function (isValid) {
        if (isValid) {
            $scope.isDisabled = true;
            $http({
                method: 'POST',
                url: get_base_url() + '/reset_password',
                data: $.param($scope.rpData),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            })

                    .success(function (data) {
                        if (!data.success) {
                            $scope.errorEmail = data.errors.email;
                            $scope.systemErrors = data.errors.email;
                            $scope.message = false;
                            $scope.isDisabled = false;
                            $scope.isEDisabled = false;
                        } else {
                            $scope.isDisabled = true;
                            $scope.isEDisabled = true;
                            $scope.message = data.success.message;
                            $scope.cvData.code = data.success.code;
                            $scope.cvData.email = data.success.email;
                            $scope.npData.code = data.success.code;
                            $scope.npData.email = data.success.email;
                            $scope.systemErrors = false;
                            $scope.errorEmail = false;
                            $scope.resetForm = false;
                        }
                    });
        }
    };

    $scope.submitcvForm = function (isValid) {
        $scope.systemErrors = false;
        if (isValid) {
            $scope.isDisabled = true;
            $http({
                method: 'POST',
                url: get_base_url() + '/code_verification',
                data: $.param($scope.cvData),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            })

                    .success(function (data) {
                        if (!data.success) {
                            $scope.errorCode = data.errors.code;
                            $scope.systemErrors = data.errors.systemError;
                            $scope.isDisabled = false;
                        } else {
                            $scope.isDisabled = true;
                            $scope.message = data.success.message;
                            $scope.errorCode = false;
                            $scope.systemErrors = false;
                            $scope.newPassword = true;
                        }
                    });
        }
    };

    $scope.submitnpForm = function (isValid) {
        $scope.systemErrors = false;
        $scope.npData.code = $scope.cvData.code;
        if (isValid) {
            $scope.isDisabled = true;
            $http({
                method: 'POST',
                url: get_base_url() + '/new_password',
                data: $.param($scope.npData),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            })

                    .success(function (data) {
                        if (!data.success) {
                            $scope.errorPass = data.errors.pass;
                            $scope.systemErrors = data.errors.systemError;
                            $scope.isDisabled = false;
                        } else {
                            $scope.isDisabled = true;
                            $scope.message = data.success.message;
                            $scope.errorCode = false;
                            $scope.systemErrors = false;
                            setTimeout(window.location.reload(), 2000);
                        }
                    });
        }
    };
    $scope.renderHtml = function (htmlCode) {
        return $sce.trustAsHtml(htmlCode);
    };
});

realestateApp.controller('workordersController', function ($scope, $http, $sce, $location, $rootScope, $i18next) {
    action_btn($rootScope);
    $('.sidebar').removeClass('cl_hide');
    $('.navbar').removeClass('cl_hide');
    $('.sidebar').addClass('cl_show');
    $('.navbar').addClass('cl_show');

    $scope.pageHeader = "Maintenance Requests";

    $scope.isDisabled = false;
    $scope.type = "";
    $scope.loadMore = true;
    $scope.orders;
    $scope.isSecured = true;
    $scope.listData = {tworkorder: null, tcost: null, ttime: null};
    $scope.buildings = [];
    $scope.mcategories = [];
    $scope.subcats = [];
    $scope.iLocations = [];
    $scope.assignees = [];
    $scope.priorities = [];
    $scope.wostatus = [];
    $scope.escalation_levels = [];
    $scope.suites_where = [];
    $scope.floors = [];

    $scope.filter = {building: {id: null, name: 'Building', condition: null, val: null, visible: true, tab_id: 1},
        status: {id: null, name: 'Status', condition: null, val: null, visible: true, tab_id: 2},
        priority: {id: null, name: 'Priority', condition: null, val: null, visible: true, tab_id: 3},
        assigned_to: {id: null, name: 'Assigned To', condition: null, val: null, visible: false, tab_id: 4},
        escalation_level: {id: null, name: 'Escalation Level', condition: null, val: null, visible: true, tab_id: 5},
        category: {id: null, name: "Category", condition: null, val: null, visible: true, tab_id: 6},
        sub_category: {id: null, name: "Sub Category", condition: null, val: null, visible: false, tab_id: 7},
        ilocation_data: {id: null, name: "Location of Issue", condition: null, val: null, visible: true, tab_id: 8},
        suite_no: {id: null, name: "Room/Suite/Room #", condition: null, val: null, visible: false, tab_id: 9},
        floor_no: {id: null, name: "Floor #", condition: null, val: null, visible: false, tab_id: 10},
        where_data: {id: null, name: "Where?", condition: null, val: null, visible: false, tab_id: 11},
        cost: {id: null, name: "Cost", condition: 1, val: null, visible: true, tab_id: 12},
        date_data: {id: null, name: "Date", condition: 1, val: null, visible: true, start: null, end: null, tab_id: 13}
    };

    $scope.woList = {index: 0, limit: 10, filter: $scope.filter, sortType: "none", type: $scope.type};

    $scope.expandFilter = function (id) {
        $('.panel-heading > a').attr('data-toggle', 'collapse');
        $('.faq-1-' + id).collapse('show');
    };

    $scope.init = function (type) {
        $scope.woList.type = type;
        toggle_left_sidebar();
        console.log(1);
        $http({
            method: 'POST',
            url: get_base_url() + '/validate_user',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        if ($rootScope.appInitFlag) {
                            $rootScope.redirectURL = $location.path();
                            login();
                        }
                    } else {
                        $scope.unseen_noti = data.success.unseen_noti;
                        if (data.success.data.user_type == 1) {
                            $scope.isSecured = true;
                            $rootScope.isSecured = true;
                            $scope.load_escalation_level();
                        } else {
                            $scope.isSecured = false;
                        }
                        $scope.loadmore_init();
                        $scope.loadBuildings();
                        $scope.loadStatus();
                        $scope.loadCats();
                        $scope.loadIssueLocations();
                        $scope.loadPriorities();
                    }
                });
    };

    $scope.init_log = function () {
        toggle_left_sidebar();
        console.log(1);
        $http({
            method: 'POST',
            url: get_base_url() + '/validate_user',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {

                    } else {
                        $scope.unseen_noti = data.success.unseen_noti;
                        if (data.success.data.user_type == 1) {
                            $scope.isSecured = true;
                            $scope.load_escalation_level();
                        } else {
                            $scope.isSecured = false;
                        }
                        $scope.loadBuildings();
                        $scope.loadStatus();
                        $scope.loadCats();
                        $scope.loadIssueLocations();
                        $scope.loadPriorities();
                    }
                });
    };

    $scope.update_filter_init = function () {
        loading(true);
        $scope.woList.index = 0;
        $scope.woList.limit = 10;
        $http({
            method: 'POST',
            url: get_base_url() + '/workorder/list',
            data: $.param($scope.woList),
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.message = false;
                        $scope.systemErrors = data.errors.systemError;
                        $scope.orders = [];
                    } else {
                        $scope.message = data.success.message;
                        $scope.orders = data.success.data;
                        if (data.success.listData) {
                            $scope.listData = angular.copy(data.success.listData);
                        }
                        $scope.woList.index++;
                        if (data.success.data.length >= $scope.woList.limit)
                            $scope.loadMore = false;
                        else
                            $scope.loadMore = true;
                        $scope.systemErrors = false;
                    }
                    loading(false);
                });
    };

    $scope.loadmore_init = function () {
        loading(true);
        $http({
            method: 'POST',
            url: get_base_url() + '/workorder/list',
            data: $.param($scope.woList),
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.message = false;
                        $scope.systemErrors = data.errors.systemError;
                    } else {
                        $scope.message = data.success.message;
                        $scope.orders = data.success.data;
                        $scope.woList.index++;
                        if (data.success.data.length >= $scope.woList.limit)
                            $scope.loadMore = false;
                        $scope.systemErrors = false;
                    }
                    loading(false);
                });
    };
    $scope.loadmore = function () {
        loading(true);
        $http({
            method: 'POST',
            url: get_base_url() + '/workorder/list',
            data: $.param($scope.woList),
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.message = false;
                        $scope.systemErrors = data.errors.systemError;
                        $scope.loadMore = true;
                    } else {
                        $scope.message = data.success.message;
                        angular.forEach(data.success.data, function (value, key) {
                            $scope.orders.push(value);
                        });
                        $scope.woList.index++;
                        if (data.success.data.length >= $scope.woList.limit)
                            $scope.loadMore = false;
                        else
                            $scope.loadMore = true;
                        $scope.systemErrors = false;
                    }
                    loading(false);
                });
    };

    $scope.updateList = function (id, name, att_name) {
        $scope.filter[att_name].id = id;
        $scope.filter[att_name].val = name;
        $scope.filter[att_name].visible = false;
        $('#filterModal').modal('hide');
        if ((att_name == "status" || att_name == "priority") && $scope.filter.ilocation_data.id == 1) {
            $scope.load_suites_where();
        }
        if ($scope.woList.type == "workorders")
            $scope.update_filter_init();
    };

    $scope.updateSortType = function () {
        $scope.orders = [];
        $scope.woList.index = 0;
        $scope.woList.limit = 10;
        if ($scope.woList.type == "workorders")
            $scope.update_filter_init();
    };

    $scope.loadBuildings = function () {
        $http({
            method: 'POST',
            url: get_base_url() + '/workorder/buildings',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                        $scope.buildings = [];
                    } else {
                        $scope.buildings = data.success.data;
                        $scope.systemErrors = false;
                    }
                });
    };

    $scope.load_escalation_level = function () {
        $http({
            method: 'POST',
            url: get_base_url() + '/filter/escalation_level',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                        $scope.escalation_levels = [];
                    } else {
                        $scope.escalation_levels = data.success.data;
                        $scope.systemErrors = false;
                    }
                });
    };

    $scope.load_suites_where = function () {
        $scope.tempsw = {id: $scope.filter.ilocation_data.id, status: $scope.filter.status.id, priority: $scope.filter.priority.id};
        $http({
            method: 'POST',
            url: get_base_url() + '/filter/suites_where',
            data: $.param($scope.tempsw),
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                        $scope.suites_where = [];
                    } else {
                        $scope.suites_where = data.success.data.suites;
                        $scope.floors = data.success.data.floors;
                        $scope.systemErrors = false;
                    }
                });
    };

    $scope.load_floors = function () {
        $http({
            method: 'POST',
            url: get_base_url() + '/filter/floors',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                        $scope.floors = [];
                    } else {
                        $scope.floors = data.success.data;
                        $scope.systemErrors = false;
                    }
                });
    };

    $scope.loadStatus = function () {
        $http({
            method: 'POST',
            url: get_base_url() + '/workorder/status',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                    } else {
                        $scope.wostatus = data.success.data;
                        $scope.systemErrors = false;
                    }
                });
    };

    $scope.building_update = function (id, name) {
        $scope.filter.building.id = id;
        $scope.filter.building.val = name;
        $scope.filter.building.visible = false;
        $('#filterModal').modal('hide');
        $scope.loadAssignees();
        if ($scope.woList.type == "workorders")
            $scope.update_filter_init();
    };

    $scope.loadCats = function () {
        $http({
            method: 'POST',
            url: get_base_url() + '/workorder/categories',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                    } else {
                        $scope.mcategories = data.success.data;
                        $scope.systemErrors = false;
                    }
                });
    };
    $scope.loadIssueLocations = function () {
        $http({
            method: 'POST',
            url: get_base_url() + '/workorder/issueLocations',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                    } else {
                        $scope.iLocations = data.success.data;
                        $scope.systemErrors = false;
                    }
                });
    };
    $scope.update_subCat = function (id, name) {
        $('#filterModal').modal('hide');
        $scope.filter.category.id = id;
        $scope.filter.category.val = name;
        $scope.filter.category.visible = false;
        $scope.filter.sub_category.visible = true;
        if ($scope.woList.type == "workorders")
            $scope.update_filter_init();
        if ($scope.filter.category.id != null) {
            $scope.temp = {id: $scope.filter.category};
            $http({
                method: 'POST',
                url: get_base_url() + '/workorder/subcategories',
                data: $.param($scope.filter.category),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            })

                    .success(function (data) {
                        if (!data.success) {
                            $scope.systemErrors = data.errors.systemError;
                            $scope.message = false;
                            $scope.subcats = [];
                        } else {
                            $scope.subcats = data.success.data;
                            $scope.systemErrors = false;
                        }
                    });
        }
    };

    $scope.loadAssignees = function () {
        if ($scope.filter.building != null) {
            $http({
                method: 'POST',
                data: $.param($scope.filter.building),
                url: get_base_url() + '/workorder/assignees',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            })

                    .success(function (data) {
                        if (!data.success) {
                            $scope.systemErrors = data.errors.systemError;
                            $scope.message = false;
                            $scope.assignees = [];
                        } else {
                            $scope.assignees = data.success.data;
                            $scope.filter.assigned_to.visible = true;
                            $scope.systemErrors = false;
                        }
                    });
        }
    };

    $scope.loadPriorities = function () {
        $http({
            method: 'POST',
            url: get_base_url() + '/workorder/priorities',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                    } else {
                        $scope.priorities = data.success.data;
                        $scope.systemErrors = false;
                    }
                });
    };

    $scope.update_ilocation = function (id, name) {
        $scope.filter.ilocation_data.id = id;
        $scope.filter.ilocation_data.val = name;
        $scope.filter.ilocation_data.visible = false;
        if (id == 1) {
            $scope.filter.suite_no.visible = true;
            $scope.filter.floor_no.visible = true;
            $scope.filter.where_data.visible = false;
            $scope.load_suites_where(id);
            $scope.load_floors();
        } else if (id == 2) {
            $scope.filter.suite_no.visible = false;
            $scope.filter.floor_no.visible = true;
            $scope.filter.where_data.visible = false;
            $scope.load_floors();
        } else {
            $scope.filter.suite_no.visible = false;
            $scope.filter.floor_no.visible = false;
            $scope.filter.where_data.visible = true;
            $scope.load_suites_where(id);
        }
        $('#filterModal').modal('hide');
        if ($scope.woList.type == "workorders")
            $scope.update_filter_init();
    };

    $scope.update_cost_condition = function (val) {
        alert('hi');
        $scope.filter.cost.condition = val;
    };

    $scope.open_workorder = function (id) {
        $location.path('/workorder/view/' + id);
    };
    $scope.renderHtml = function (htmlCode) {
        return $sce.trustAsHtml(htmlCode);
    };
});

realestateApp.controller('contactsController', function ($scope, $http, $location, $rootScope) {
    action_btn($rootScope);
    $scope.pageHeader = "Contacts";
    $scope.loginData = {};
    $scope.isSecured = false;
    $scope.userData;
    $scope.contacts = [];
    $scope.contactList = {building_id: 0, user_type: 0, index: 0, limit: 20};

    $scope.buildings = [];
    $scope.building = 0;

    $scope.searchText;

    $scope.isVisible = false;
    $scope.loadMore = true;
    $scope.isLast = true;

    $scope.init = function (type) {
        toggle_left_sidebar();
        $scope.contactList.user_type = type;
        if (type) {
            $scope.pageHeader = "Managers Contacts";
        } else {
            $scope.pageHeader = "Tenants Contacts";
        }
        console.log(1);
        $http({
            method: 'POST',
            url: get_base_url() + '/validate_user',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                        if ($rootScope.appInitFlag) {
                            $rootScope.redirectURL = $location.path();
                            login();
                        }
                    } else {
                        $scope.unseen_noti = data.success.unseen_noti;
                        if (data.success.data.user_type == 1) {
                            $scope.isSecured = true;
                            $rootScope.isSecured = true;
                        }
                        $scope.loadBuildings();
                        //$scope.message = data.success.message;
                        $scope.systemErrors = false;
                    }
                });
    };

    $scope.loadBuildings = function () {
        $http({
            method: 'POST',
            url: get_base_url() + '/workorder/buildings',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                        $scope.buildings = [];
                    } else {
                        $scope.buildings = data.success.data;
                        if ($scope.buildings.length == 1) {
                            $scope.building = $scope.buildings[0];
                            $scope.loadContacts();
                        }
                        $scope.systemErrors = false;
                    }
                });
    };

    $scope.loadmore_init = function () {
        loading(true);
        $http({
            method: 'POST',
            url: get_base_url() + '/contacts/get_manager_list',
            data: $.param($scope.contactList),
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.message = false;
                        $scope.isVisible = false;
                        //$scope.systemErrors = data.errors.systemError;
                        loading(false);
                    } else {
                        $scope.isVisible = true;
                        //$scope.message = data.success.message;
                        $scope.contactList.index += data.success.data.length;
                        if (data.success.data.length >= $scope.contactList.limit)
                            $scope.loadMore = false;

                        $scope.contacts = data.success.data;
                        $scope.systemErrors = false;
                        $scope.isLast = data.success.isLast;
                        loading(false);
                    }
                });
    };

    $scope.loadmore_act = function () {
        loading(true);
        $http({
            method: 'POST',
            url: get_base_url() + '/contacts/get_manager_list',
            data: $.param($scope.contactList),
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.message = false;
                        //$scope.systemErrors = data.errors.systemError;
                        loading(false);
                    } else {
                        $scope.isVisible = true;
                        //$scope.message = data.success.message;
                        $scope.contactList.index += data.success.data.length;
                        if (data.success.data.length >= $scope.contactList.limit)
                            $scope.loadMore = false;
                        else
                            $scope.loadMore = true;
                        angular.forEach(data.success.data, function (value, key) {
                            $scope.contacts.push(value);
                        });
                        $scope.systemErrors = false;
                        $scope.isLast = data.success.isLast;
                        loading(false);
                    }
                });
    };

    $scope.updateResult = function () {
        if ($scope.building != null && $scope.building != 0) {
            $scope.contactList.searchQuery = $scope.searchText;
            $scope.isLast = true;
            $scope.contactList.limit = 20;
            $scope.contactList.index = 0;
            $scope.loadmore_init();
        }
    };

    $scope.redirectToProfile = function (id) {
        $location.path("/profile/info/" + id);
    };

    $scope.loadContacts = function () {
        if ($scope.building != null) {
            $scope.contactList.building_id = $scope.building.id;
            $scope.loadmore_init();
        } else {
            $scope.isVisible = false;
        }
    };
});

realestateApp.controller('profileController', function ($scope, $http, $sce, dateFilter, $stateParams, $location, $rootScope) {
    action_btn($rootScope);
    $scope.pageHeader = "Profile";
    $scope.profile_img_file = "";
    $scope.isDisabled = false;
    $scope.isHidden = true;
    $scope.userData;
    $scope.managerEnabled = false;
    $scope.loggedIn = false;
    $scope.ufData;
    $scope.init = function () {
        toggle_left_sidebar();
        if ($stateParams.profileID) {
            $scope.temp_data = {id: $stateParams.profileID};
            $http({
                method: 'POST',
                data: $.param($scope.temp_data),
                url: get_base_url() + '/user/info',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            })

                    .success(function (data) {
                        if (!data.success) {
                            $scope.isHidden = true;
                            $scope.message = false;
                            $scope.systemErrors = data.errors.systemError;
                            if (data.errors.redirectTo) {
                                $location.path(data.errors.redirectTo);
                            }
                        } else {
                            $scope.isHidden = false;
                            //$scope.message = data.success.message;
                            $scope.userData = data.success.data;
                            $scope.systemErrors = false;
                            $("#profile_pic").attr('src', data.success.pic_url);
                            $scope.loggedIn = data.success.isEditable;
                            if ($scope.loggedIn) {
                                $scope.ufData = angular.copy(data.success.user_info);
                                $scope.ufData.birthday = new Date(data.success.user_info.birthday);
                                $rootScope.cameraBtn = true;
                                if (data.success.user_info.gender)
                                    $scope.ufData.gender = 1;
                                else
                                    $scope.ufData.gender = 0;
                            }

                            if (data.success.manager == 1) {
                                $rootScope.isSecured = true;
                                $scope.managerEnabled = true;
                                $scope.isSecured = true;
                            }
                        }
                    });
        } else {
            console.log(1);
            $http({
                method: 'POST',
                url: get_base_url() + '/validate_user',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            })

                    .success(function (data) {
                        if (!data.success) {

                        } else {
                            $scope.unseen_noti = data.success.unseen_noti;
                            $location.path("/profile/info/" + data.success.data.id);
                        }
                    });
        }
    };
    $scope.updatePrivacySetting = function ($event, type) {
        var checkbox = $event.target;
        var action = (checkbox.checked ? 1 : 0);
        $scope.temp_data = {type: type, val: action};
        $http({
            method: 'POST',
            data: $.param($scope.temp_data),
            url: get_base_url() + '/user/update/privacy_settings',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                    } else {
                        $scope.responseMessage = data.success.message;
                        $scope.systemErrors = false;
                    }
                });
    };

    $scope.update_myprofile = function (isValid) {
        if (isValid) {
            loading(true);
            $http({
                method: 'POST',
                data: $.param($scope.ufData),
                url: get_base_url() + '/user/update/profile',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            })

                    .success(function (data) {
                        if (!data.success) {
                            $("html, body").animate({scrollTop: 0}, 600);
                            $scope.systemErrors_2 = data.errors.systemError;
                            $scope.message_2 = false;
                        } else {
                            $scope.message_2 = data.success.message;
                            $scope.systemErrors_2 = false;
                            setTimeout($('#myProfileEditModal').modal('hide'), 1000);
                            $scope.init();
                        }
                        loading(false);
                    });
        } else {
            $("html, body").animate({scrollTop: 0}, 600);
            $scope.systemErrors = "Please fill all required fields.";
            $scope.message = false;
        }
    };

    $scope.renderHtml = function (htmlCode) {
        return $sce.trustAsHtml(htmlCode);
    };

    $scope.camera_upload = function () {
        $("input[id='my_file']").click();
    };

    $scope.prepareUpload = function (event) {
        var files = event.target.files;
        if (files.length > 0) {
            loading(true);
            event.stopPropagation(); // Stop stuff happening
            event.preventDefault(); // Totally stop stuff happening

            // START A LOADING SPINNER HERE

            // Create a formdata object and add the files
            var data = new FormData();
            $.each(files, function (key, value)
            {
                data.append(key, value);
            });

            $.ajax({
                url: get_base_url() + '/user/upload/profilePic',
                type: 'POST',
                data: data,
                cache: false,
                dataType: 'json',
                processData: false, // Don't process the files
                contentType: false, // Set content type to false as jQuery will tell the server its a query string request
                success: function (data, textStatus, jqXHR)
                {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                    } else {
                        $scope.message = 'Profile Picture updated successfully.';
                        $scope.systemError = false;
                        $("#profile_pic").attr('src', data.success.data.pic_url);
                        $rootScope.profilePic = data.success.data.pic_url_thumb;
                    }
                    loading(false);
                    $("html, body").animate({scrollTop: 0}, 600);
                    $scope.$digest();
                    $rootScope.$digest();
                },
                error: function (jqXHR, textStatus, errorThrown)
                {
                    $scope.message = false;
                    $scope.systemErrors = "Videos and audio recordings cannot be uploaded. You can only upload photos.";
                    loading(false);
                    $("html, body").animate({scrollTop: 0}, 600);
                    $scope.$digest();
                }
            });
        }
    };
});

realestateApp.controller('settingsController', function ($scope, $http, $location, $rootScope) {
    action_btn($rootScope);
    $scope.pageHeader = "Settings";
    $scope.notifications;

    $scope.priorities = [];
    $scope.spriority = {label_15: "", label_17: ""};
    $scope.init = function () {
        toggle_left_sidebar();
        console.log(1);
        $http({
            method: 'POST',
            url: get_base_url() + '/validate_user',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        if ($rootScope.appInitFlag) {
                            $rootScope.redirectURL = $location.path();
                            login();
                        }
                    } else {
                        $scope.unseen_noti = data.success.unseen_noti;
                        if (data.success.data.user_type == 1) {
                            $scope.isSecured = true;
                            $rootScope.isSecured = true;
                        }
                        $scope.after_init();
                    }
                });
    };
    $scope.after_init = function () {
        $http({
            method: 'POST',
            url: get_base_url() + '/notification/settings',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.message = false;
                        $scope.systemErrors = data.errors.systemError;

                        $location.path('/workorder/view/' + id);
                    } else {
                        $scope.loadPriorities();
                        $scope.message = data.success.message;
                        $scope.notifications = data.success.data;
                        $scope.systemErrors = false;
                    }
                });
    };
    $scope.updateSelection = function ($event, id, type) {
        var checkbox = $event.target;
        var action = (checkbox.checked ? 1 : 0);
        $scope.temp_data = {id: id, type: type, val: action};

        $http({
            method: 'POST',
            url: get_base_url() + '/notification/settings/update',
            data: $.param($scope.temp_data),
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.message = false;
                        $scope.systemErrors = data.errors.systemError;
                        checkbox.checked = (checkbox.checked ? false : true);
                    } else {
                        $scope.message = data.success.message;
                        $scope.systemErrors = false;
                    }
                });
    };

    $scope.loadPriorities = function () {
        $http({
            method: 'POST',
            url: get_base_url() + '/workorder/priorities',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                    } else {
                        $scope.priorities = data.success.data;
                        $scope.systemErrors = false;
                    }
                });
    };
    $scope.updateSettings = function (ref_id) {
        var temp_val = "";
        if (ref_id == 15 && $scope.spriority.label_15 != null) {
            temp_val = $scope.spriority.label_15;
        } else if (ref_id == 17 && $scope.spriority.label_17 != null) {
            temp_val = $scope.spriority.label_17;
        }

        if (temp_val != "") {
            $scope.temp_data = {id: ref_id, type: 'priority', val: temp_val};
            $http({
                method: 'POST',
                url: get_base_url() + '/notification/settings/update_condition',
                data: $.param($scope.temp_data),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            })

                    .success(function (data) {
                        if (!data.success) {
                            $scope.message = false;
                            $scope.systemErrors = data.errors.systemError;
                            checkbox.checked = (checkbox.checked ? false : true);
                        } else {
                            $scope.message = data.success.message;
                            $scope.systemErrors = false;
                        }
                    });
        }
    };
});

realestateApp.controller('workorderviewController', function ($scope, $http, $sce, $stateParams, $location, $rootScope) {
    action_btn($rootScope);
    $scope.woData = {id: $stateParams.id};
    $scope.isDisabled = false;
    $scope.workData = {id: $stateParams.id};
    $scope.order;
    $scope.managerEnabled = false;
    $scope.noteData = {id: $stateParams.id};
    $scope.isCompleted = false;

    $scope.iLocations = [];
    $scope.workData.issue_location;

    $scope.buildings = [];
    $scope.workData.building;

    $scope.mcategories = [];
    $scope.workData.cat;

    $scope.subcats = [];
    $scope.workData.subcat;
    $scope.floorFlag = false;

    $scope.init = function () {
        toggle_left_sidebar();
        loading(true);
        $http({
            method: 'POST',
            url: get_base_url() + '/workorder/view',
            data: $.param($scope.woData),
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.message = false;
                        $scope.systemErrors = data.errors.systemError;
                        $('#view_history').css('display', 'none');
                        if ($rootScope.appInitFlag) {
                            $rootScope.redirectURL = $location.path();
                            login();
                        }
                    } else {
                        $scope.pageHeader = "Maintenance Request #" + $scope.woData.id;
                        //$scope.message = data.success.message;
                        $scope.order = data.success.data;
                        $scope.work_data = data.success.work_data;
                        if ($scope.order.status == 9) {
                            $scope.isCompleted = true;
                        }
                        $scope.systemErrors = false;
                        //$scope.workData = data.success.workData;
                        if (data.success.manager == 1) {
                            $rootScope.isSecured = true;
                            $scope.managerEnabled = true;
                            $scope.isSecured = true;
                        }
                        if (data.success.jobFlag == 0) {
                            $('#view_history').css('display', 'none');
                        }
                        $scope.loadCats();
                        $scope.loadIssueLocations();
                        $scope.loadBuildings();
                        $scope.workData = angular.copy(data.success.workData);
                        $scope.update_subCat();
                        $scope.issueLocationFlag = true;
                    }
                    loading(false);
                });
    };

    $scope.receipt_file_upload = function (event) {
        var files = event.target.files;
        if (files.length > 0) {
            loading(true);
            event.stopPropagation(); // Stop stuff happening
            event.preventDefault(); // Totally stop stuff happening

            // START A LOADING SPINNER HERE

            // Create a formdata object and add the files
            var data = new FormData();
            $.each(files, function (key, value)
            {
                data.append(key, value);
            });

            $.ajax({
                url: get_base_url() + '/workorderjob/receipt_upload?id=' + $scope.workData.id,
                type: 'POST',
                data: data,
                cache: false,
                dataType: 'json',
                processData: false, // Don't process the files
                contentType: false, // Set content type to false as jQuery will tell the server its a query string request
                success: function (data, textStatus, jqXHR)
                {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                    } else {
                        //$scope.message = 'Picture uploaded successfully.';
                        $scope.systemError = false;
                        $rootScope.$emit('scroll_down_to_workorderjoblist', event);
                        //window.history.pushState('workorderview', 'Workorder View', '#/workorder/view/'+$scope.workData.id+'/true');
                    }
                    loading(false);
                    $scope.$digest();
                },
                error: function (jqXHR, textStatus, errorThrown)
                {
                    $scope.message = false;
                    $scope.systemErrors = "Videos and audio recordings cannot be uploaded. You can only upload photos.";
                    loading(false);
                    $scope.$digest();
                    $("html, body").animate({scrollTop: 0}, 600);
                }
            });
        }
    };

    $scope.prepareUpload2 = function (event) {
        var files = event.target.files;
        if (files.length > 0) {
            loading(true);
            event.stopPropagation(); // Stop stuff happening
            event.preventDefault(); // Totally stop stuff happening

            // START A LOADING SPINNER HERE

            // Create a formdata object and add the files
            var data = new FormData();
            $.each(files, function (key, value)
            {
                data.append(key, value);
            });

            $.ajax({
                url: get_base_url() + '/workorderjob/photo_upload_web?id=' + $scope.workData.id,
                type: 'POST',
                data: data,
                cache: false,
                dataType: 'json',
                processData: false, // Don't process the files
                contentType: false, // Set content type to false as jQuery will tell the server its a query string request
                success: function (data, textStatus, jqXHR)
                {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                    } else {
                        //$scope.message = 'Picture uploaded successfully.';
                        $scope.systemError = false;
                        $rootScope.$emit('scroll_down_to_workorderjoblist', event);
                        //window.history.pushState('workorderview', 'Workorder View', '#/workorder/view/'+$scope.workData.id+'/true');
                    }
                    loading(false);
                    $scope.$digest();
                },
                error: function (jqXHR, textStatus, errorThrown)
                {
                    $scope.message = false;
                    $scope.systemErrors = "Videos and audio recordings cannot be uploaded. You can only upload photos.";
                    loading(false);
                    $scope.$digest();
                }
            });
        }
    };

    $scope.get_user = function () {
        console.log('get_usr');
        $http({
            method: 'POST',
            url: get_base_url() + '/validate_user',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                        if ($rootScope.appInitFlag) {
                            $rootScope.redirectURL = $location.path();
                            login();
                        }
                    } else {
                        $rootScope.cameraBtn = true;
                        $scope.unseen_noti = data.success.unseen_noti;
                        if (data.success.data.user_type == 1) {
                            $scope.isSecured = true;
                            $rootScope.receiptBtn = true;
                        }
                        $scope.init();
                        $("#user_id").val(data.success.data.id);
                    }
                });
    };

    $scope.update_iLoc = function () {
        if ($scope.workData.issue_location != null) {
            console.log($scope.workData.issue_location);
            $scope.issueLocationFlag = true;
            $scope.issue_location = $scope.iLocations[$scope.workData.issue_location - 1].label;

            $scope.issue_location_id = $scope.iLocations[$scope.workData.issue_location - 1].id;
            if ($scope.workData.issue_location == 1) {
                $scope.floorFlag = true;
            } else {
                $scope.floorFlag = false;
            }

        } else if ($scope.workData.issue_location == null) {
            $scope.issueLocationFlag = false;
        }
    }

    $scope.add_note = function (isValid) {
        if (isValid) {
            $http({
                method: 'POST',
                data: $.param($scope.noteData),
                url: get_base_url() + '/workorderjob/add_note',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            })

                    .success(function (data) {
                        if (!data.success) {
                            $scope.systemErrors_2 = data.errors.systemError;
                            $scope.message_2 = false;
                        } else {
                            $scope.message_2 = data.success.message;
                            $scope.systemErrors_2 = false;
                            $scope.resetForm();
                            setTimeout($scope.hideModal, 1000);
                            $location.path("/workorder/view/" + $stateParams.id + "/ture");
                        }
                    });
        }
    };

    $scope.isCost = function (att) {
        if ($scope.managerEnabled)
            return true;
        else {
            if (att.label == "Cost")
                return false;
            else
                return true;
        }
    };

    $scope.hideModal = function () {
        $('#myModal').modal('hide');
    };

    $scope.resetForm = function () {
        $scope.noteData = {};
        $scope.noteForm.$setPristine();
    };
    $scope.renderHtml = function (htmlCode) {
        return $sce.trustAsHtml(htmlCode);
    };

    $scope.loadCats = function () {
        $http({
            method: 'POST',
            url: get_base_url() + '/workorder/categories',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                    } else {
                        $scope.mcategories = data.success.data;
                        $scope.systemErrors = false;
                    }
                });
    };
    $scope.loadIssueLocations = function () {
        $http({
            method: 'POST',
            url: get_base_url() + '/workorder/issueLocations',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                    } else {
                        $scope.iLocations = data.success.data;
                        $scope.update_iLoc();
                        $scope.systemErrors = false;
                    }
                });
    };
    $scope.update_subCat = function () {
        if ($scope.workData.cat != null) {
            $scope.temp = {id: $scope.workData.cat};
            $http({
                method: 'POST',
                url: get_base_url() + '/workorder/subcategories',
                data: $.param($scope.temp),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            })

                    .success(function (data) {
                        if (!data.success) {
                            $scope.systemErrors = data.errors.systemError;
                            $scope.message = false;
                            $scope.subcats = [];
                        } else {
                            $scope.subcats = data.success.data;
                            $scope.systemErrors = false;
                        }
                    });
        }
    };
    $scope.loadBuildings = function () {
        $http({
            method: 'POST',
            url: get_base_url() + '/workorder/buildings',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                        $scope.buildings = [];
                    } else {
                        $scope.buildings = data.success.data;
                        $scope.workData.building = data.success.data[0];
                        $scope.systemErrors = false;
                    }
                });
    };
    $scope.update_workOrder = function (isValid) {
        if (isValid) {
            loading(true);
            $http({
                method: 'POST',
                data: $.param($scope.workData),
                url: get_base_url() + '/workorder/update',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            })

                    .success(function (data) {
                        if (!data.success) {
                            $("html, body").animate({scrollTop: 0}, 600);
                            $scope.systemErrors_2 = data.errors.systemError;
                            $scope.message_2 = false;
                        } else {
                            $scope.message_2 = data.success.message;
                            $scope.systemErrors_2 = false;
                            $scope.resetForm();
                            setTimeout($('#workOrderUpdateModal').modal('hide'), 1000);
                            $location.path("/workorder/view/" + $stateParams.id + "/ture");
                            $scope.init();
                        }
                        loading(false);
                    });
        } else {
            $("html, body").animate({scrollTop: 0}, 600);
            $scope.systemErrors = "Please fill all required fields.";
            $scope.message = false;
        }
    };
});

realestateApp.controller('workOrderJobListController', function ($scope, $http, $sce, $stateParams, $location, $rootScope) {
    action_btn($rootScope);
    $scope.deletedFlag = false;
    $scope.woList = {index: 0, limit: 10, id: $stateParams.id, deleted: $scope.deletedFlag, max: 0, min: 0};
    $scope.isDisabled = false;
    $scope.loadMore = true;
    $scope.jobs;
    $scope.delete_id = 0;
    $scope.noData = true;
    $scope.isviewButton = true;
    $scope.isLast = false;

    $rootScope.$on('scroll_down_to_workorderjoblist', function (event, args) {
        $scope.woList.index = 0;
        $scope.woList.max = 0;
        $scope.woList.min = 0;
        $scope.woList.limit = 10;
        $scope.scrollDown();
    });

    $scope.jlinit = function () {
        toggle_left_sidebar();
        loading(true);
        $http({
            method: 'POST',
            url: get_base_url() + '/workorderjob/list',
            data: $.param($scope.woList),
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.message = false;
                        $scope.systemErrors = data.errors.systemError;

                    } else {
                        $scope.isviewButton = false;
                        $scope.message = data.success.message;
                        $scope.jobs = data.success.data;
                        $scope.woList.index += data.success.data.length;
                        if (data.success.data.length > 0) {
                            $scope.woList.min = data.success.data[0].workorderjob_no;
                        }
                        $scope.jobs.forEach(function (entry) {
                            if (entry.workorderjob_no > $scope.woList.max) {
                                $scope.woList.max = entry.workorderjob_no;
                            }
                            if (entry.workorderjob_no < $scope.woList.min) {
                                $scope.woList.min = entry.workorderjob_no;
                            }
                        });
                        if (data.success.data.length >= $scope.woList.limit)
                        {
                            $scope.loadMore = false;
                        } else {
                            $scope.loadMore = true;
                            $scope.noData = false;
                        }
                        $scope.systemErrors = false;
                        $scope.isLast = data.success.isLast;
                    }
                    loading(false);
                });
    };
    $scope.scrollDown = function () {
        $scope.jlinit();
        $('html, body').animate({
            scrollTop: $("#workorderJobList").offset().top - 100
        }, 2000);
    };
    $scope.renderHtml = function (htmlCode) {
        return $sce.trustAsHtml(htmlCode);
    };
    $scope.loadmore = function () {
        loading(true);
        $http({
            method: 'POST',
            url: get_base_url() + '/workorderjob/list',
            data: $.param($scope.woList),
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.message = false;
                        $scope.systemErrors = data.errors.systemError;
                    } else {
                        $scope.message = data.success.message;
                        angular.forEach(data.success.data, function (value, key) {
                            $scope.jobs.push(value);
                        });
                        $scope.jobs.forEach(function (entry) {
                            if (entry.workorderjob_no > $scope.woList.max) {
                                $scope.woList.max = entry.workorderjob_no;
                            }
                            if (entry.workorderjob_no < $scope.woList.min) {
                                $scope.woList.min = entry.workorderjob_no;
                            }
                        });
                        $scope.woList.index += data.success.data.length;
                        if (data.success.data.length >= $scope.woList.limit)
                            $scope.loadMore = false;
                        else {
                            $scope.loadMore = true;
                            $scope.noData = false;
                        }
                        $scope.systemErrors = false;
                        $scope.isLast = data.success.isLast;
                    }
                    loading(false);
                });
    };
    $scope.open_workorder = function (id) {
        $location.path('/workorder/view/' + id);
    };
    $scope.delete = function (id) {
        $scope.delete_id = id;
        $('#ConfirmationModal').modal('show');
    };
    $scope.updateDeletedFlag = function ($event) {
        loading(true);
        var checkbox = $event.target;
        $scope.deletedFlag = (checkbox.checked ? false : true);
        $scope.woList.deleted = $scope.deletedFlag;
        if ($scope.deletedFlag) {
            $http({
                method: 'POST',
                url: get_base_url() + '/workorderjob/deletedlist',
                data: $.param($scope.woList),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            })

                    .success(function (data) {
                        if (!data.success) {
                            $scope.message = false;
                            $scope.systemErrors = data.errors.systemError;
                        } else {
                            $scope.message = data.success.message;
                            angular.forEach(data.success.data, function (value, key) {
                                $scope.jobs.push(value);
                            });
                            $scope.woList.index += data.success.data.length;
                            $scope.systemErrors = false;
                        }
                        loading(false);
                    });
        }
    };
    $scope.confirmed = function () {
        alert($scope.delete_id);
        if ($scope.delete_id != 0) {
            $scope.temp = {id: $scope.delete_id};
            $http({
                method: 'POST',
                url: get_base_url() + '/workorderjob/delete',
                data: $.param($scope.temp),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            })

                    .success(function (data) {
                        if (!data.success) {
                            $scope.message = false;
                            $scope.systemErrors = data.errors.systemError;
                        } else {
                            $('#ConfirmationModal').modal('hide');
                            $('#myModal_woj').modal('show');
                            $scope.message = data.success.message;
                            for (index = 0, len = $scope.jobs.length; index < len; ++index) {
                                if ($scope.delete_id == $scope.jobs[index].workorderjob_no) {
                                    $scope.jobs[index].isDeleted = true;
                                    $scope.delete_id = 0;
                                }
                            }
                            $scope.systemErrors = false;
                        }
                    });
        }
    }
    $scope.open_creater_profile = function (id) {
        $location.path('/profile/info/' + id);
    };
});

realestateApp.controller('workorderCreationController', function ($scope, $http, $location, $rootScope, dateFilter) {
    action_btn($rootScope);
    $scope.loginData = {};
    $scope.workorder_id = 0;
    $scope.presenceFlag = true;
    $scope.isDisabled = false;
    $scope.isHidden = false;
    $scope.floorFlag = false;
    $scope.issueLocationFlag = false;
    $scope.workData = {};
    $scope.userData = {};
    $scope.mcategories = [];
    $scope.workData.cat;

    $scope.secureFlag = false;
    $scope.workData.presence = 1;

    $scope.iLocations = [];
    $scope.workData.issue_location;

    $scope.priorities = [];
    $scope.workData.priority;

    $scope.buildings = [];
    $scope.workData.building;

    $scope.assignees = [];
    $scope.workData.assignee = -1;

    $scope.workData.time1_from = dateFilter('09:00 AM', 'h:mm a');
    $scope.workData.time2_from = dateFilter('09:00 AM', 'h:mm a');
    $scope.workData.time1_to = dateFilter('05:00 PM', 'h:mm a');
    $scope.workData.time2_to = dateFilter('05:00 PM', 'h:mm a');

    $scope.apartment_no = 0;
    $scope.floor_no = 0;

    $scope.update_form = function () {
        if ($scope.workData.presence == 0) {
            $scope.isHidden = true;
        } else {
            $scope.isHidden = false;
        }
    }
    $scope.update_iLoc = function () {
        if ($scope.workData.issue_location != null) {
            $scope.issueLocationFlag = true;
            $scope.issue_location_id = $scope.workData.issue_location.id;
            $scope.issue_location = $scope.workData.issue_location.label;
            if ($scope.workData.issue_location.floor == 1) {
                $scope.floorFlag = true;
                $scope.workData.floor_no = $scope.floor_no;
            } else {
                $scope.floorFlag = false;
            }
            if ($scope.issue_location_id == 1) {
                $scope.workData.iLoc_data = $scope.apartment_no;
            } else if ($scope.issue_location_id == 2) {
                $scope.workData.iLoc_data = $scope.floor_no;
            }
        } else if ($scope.workData.issue_location_id == null) {
            $scope.issueLocationFlag = false;
        }
    }
    $scope.init = function () {
        toggle_left_sidebar();
        console.log(1);
        $http({
            method: 'POST',
            url: get_base_url() + '/validate_user',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })
                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                        if ($rootScope.appInitFlag) {
                            $rootScope.redirectURL = $location.path();
                            login();
                        }
                    } else {
                        //$scope.message = data.success.message;
                        $scope.unseen_noti = data.success.unseen_noti;
                        $scope.userData = data.success.data;
                        $scope.systemErrors = false;
                        $scope.loadCats();
                        $scope.loadIssueLocations();
                        $scope.loadBuildings();
                        if ($scope.userData.user_type == 1) {
                            $rootScope.isSecured = true;
                            $scope.secureFlag = true;
                            $scope.isSecured = true;
                            $scope.presenceFlag = false;
                            $scope.loadPriorities();
                        }
                    }
                });
    };
    $scope.loadCats = function () {
        $http({
            method: 'POST',
            url: get_base_url() + '/workorder/categories',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                    } else {
                        $scope.mcategories = data.success.data;
                        $scope.systemErrors = false;
                    }
                });
    };
    $scope.loadIssueLocations = function () {
        $http({
            method: 'POST',
            url: get_base_url() + '/workorder/issueLocations',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                    } else {
                        $scope.iLocations = data.success.data;
                        $scope.systemErrors = false;
                    }
                });
    };
    $scope.loadPriorities = function () {
        $http({
            method: 'POST',
            url: get_base_url() + '/workorder/priorities',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                    } else {
                        $scope.priorities = data.success.data;
                        $scope.workData.priority = "3";
                        $scope.systemErrors = false;
                    }
                });
    };
    $scope.update_subCat = function () {
        if ($scope.workData.cat != null) {
            $scope.workData.priority = $scope.workData.cat.d_priority;
            $http({
                method: 'POST',
                url: get_base_url() + '/workorder/subcategories',
                data: $.param($scope.workData.cat),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            })

                    .success(function (data) {
                        if (!data.success) {
                            $scope.systemErrors = data.errors.systemError;
                            $scope.message = false;
                            $scope.subcats = [];
                        } else {
                            $scope.subcats = data.success.data;
                            $scope.systemErrors = false;
                        }
                    });
        }
    };
    $scope.loadBuildings = function () {
        $http({
            method: 'POST',
            url: get_base_url() + '/workorder/buildings',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                        $scope.buildings = [];
                    } else {
                        $scope.buildings = data.success.data;
                        $scope.workData.building = data.success.data[0];
                        $scope.loadAssignees();
                        $scope.systemErrors = false;
                    }
                });
    };
    $scope.loadAssignees = function () {
        if ($scope.workData.building != null) {
            $http({
                method: 'POST',
                data: $.param($scope.workData.building),
                url: get_base_url() + '/workorder/assignees',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            })

                    .success(function (data) {
                        if (!data.success) {
                            $scope.systemErrors = data.errors.systemError;
                            $scope.message = false;
                            $scope.assignees = [];
                            $scope.workData.assignee = -1;
                        } else {
                            $scope.assignees = data.success.data;
                            $scope.workData.assignee = data.success.default_manager_id;
                            $scope.systemErrors = false;
                            if ($scope.userData.user_type == 0) {
                                if (data.success.apart_no) {
                                    $scope.apartment_no = data.success.apart_no;
                                }
                                if (data.success.floor_no) {
                                    $scope.floor_no = data.success.floor_no;
                                }
                            }
                        }
                    });
        }
    };
    $scope.save_workOrder = function (isValid) {
        loading(true);
        if (isValid) {
            $http({
                method: 'POST',
                data: $.param($scope.workData),
                url: get_base_url() + '/workorder/save',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            })

                    .success(function (data) {
                        if (!data.success) {
                            $("html, body").animate({scrollTop: 0}, 600);
                            $scope.systemErrors = data.errors.systemError;
                            $scope.message = false;
                            $('#myModal').modal('show');
                        } else {
                            $scope.message = data.success.message;
                            $scope.systemErrors = false;
                            $scope.resetForm();
                            $('#myModal').modal('show');
                            $scope.workorder_id = data.success.id;
                        }
                        loading(false);
                    });
        } else {
            $("html, body").animate({scrollTop: 0}, 600);
            $scope.systemErrors = "Please fill all required fields.";
            $scope.message = false;
        }
    };
    $scope.resetForm = function () {
        $scope.workData = {};
        $scope.woForm.$setPristine();
    };
    $scope.get_workorder_view = function () {
        $('#myModal').modal('hide');
        $location.path('/workorder/view/' + $scope.workorder_id);
    };
});

realestateApp.controller('workorderJobCreationController', function ($scope, $http, dateFilter, $stateParams, $location, $rootScope) {
    action_btn($rootScope);
    $scope.secureFlag = false;
    $scope.isCompletedFlag = false;
    $scope.isEscalateFlag = false;

    $scope.isRequired = false;

    $scope.workData = {id: $stateParams.id, amount: 0, autoSubmit: true};
    $scope.temp_workData;
    $scope.workorder_id = $stateParams.id;
    $scope.workData.startTime = dateFilter(new Date(), 'h:mm a');
    $scope.workData.endTime = dateFilter(new Date(), 'h:mm a');

    $scope.workData.date1 = new Date();
    $scope.workData.date2 = new Date();

    $scope.workData.wo_complete = 0;
    $scope.workData.wo_escalate = 0;

    $scope.priorities = [];
    $scope.workData.priority;

    $scope.assignees = [];
    $scope.workData.assignee;

    $scope.building_id = 0;

    $scope.popupMessage = "Detail Saved";

    $scope.isSaved = false;
    $("html, body").animate({scrollTop: 0}, 600);

    $scope.init = function () {
        toggle_left_sidebar();
        console.log(1);
        $http({
            method: 'POST',
            url: get_base_url() + '/validate_user',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })
                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                        if ($rootScope.appInitFlag)
                            login();
                    } else {
                        //$scope.message = data.success.message;
                        $scope.unseen_noti = data.success.unseen_noti;
                        $scope.workData.startTime = data.success.time;
                        $('#startTime').timepicker({
                            setTime: data.success.time
                        });
                        $('#endTime').timepicker({
                            setTime: data.success.time
                        });
                        $scope.userData = data.success.data;
                        $scope.systemErrors = false;
                        $scope.loadPriorities();
                        $scope.loadWorkOrderDetail();
                        if ($scope.userData.user_type == 1) {
                            $rootScope.isSecured = true;
                            $scope.secureFlag = true;
                            $scope.isSecured = true;
                            $scope.presenceFlag = false;
                        }
                        $scope.temp_workData = angular.copy($scope.workData);
                    }
                });
    };
    $scope.update_form = function () {
        if ($scope.workData.wo_complete == 0) {
            $scope.isCompletedFlag = false;
        } else {
            $scope.popupMessage = "Maintenance Request job completed.";
            $scope.isCompletedFlag = true;
        }

        if ($scope.workData.wo_escalate == 0) {
            $scope.isEscalateFlag = false;
        } else {
            $scope.isEscalateFlag = true;
        }
    };
    $scope.loadPriorities = function () {
        $http({
            method: 'POST',
            url: get_base_url() + '/workorder/priorities',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                    } else {
                        $scope.priorities = data.success.data;
                        $scope.systemErrors = false;
                    }
                    $scope.temp_workData = angular.copy($scope.workData);
                });
    };
    $scope.loadAssignees = function () {
        $scope.building = {};
        $scope.building.id = $scope.building_id;
        $http({
            method: 'POST',
            data: $.param($scope.building),
            url: get_base_url() + '/workorder/assignees',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                        $scope.assignees = [];
                        $scope.workData.assignee = -1;
                    } else {
                        $scope.assignees = data.success.data;
                        $scope.systemErrors = false;
                    }
                    $scope.temp_workData = angular.copy($scope.workData);
                });
    };
    $scope.loadWorkOrderDetail = function () {
        $http({
            method: 'POST',
            data: $.param($scope.workData),
            url: get_base_url() + '/workorder/building_id',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                        $scope.assignees = [];
                        $scope.workData.assignee = -1;
                    } else {
                        $scope.order = data.success.data;
                        $scope.systemErrors = false;
                        $scope.building_id = data.success.data.building_id;
                        $scope.workData.priority = data.success.data.priority;
                        $scope.loadAssignees();
                        $scope.workData.assignee = data.success.data.assignee_id;
                    }
                });
    };

    $scope.updateData = function () {
        $scope.temp_workData.date1 = $scope.workData.date1;
        $scope.temp_workData.date2 = $scope.workData.date2;

        $scope.temp_workData.autoSubmit = $scope.workData.autoSubmit;

        $scope.temp_workData.startTime = $scope.workData.startTime;
        $scope.temp_workData.endTime = $scope.workData.endTime;
    };
    $scope.save_workOrder = function (isValid) {
        loading(true);
        if (isValid) {
            if (angular.equals($scope.workData, $scope.temp_workData)) {
                $scope.systemErrors = "To submit a work update, you must add or modify at least 1 thing.";
                $('html, body').animate({scrollTop: '0px'}, 600);
            } else {
                $http({
                    method: 'POST',
                    data: $.param($scope.workData),
                    url: get_base_url() + '/workorderjob/save',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                })

                        .success(function (data) {
                            if (!data.success) {
                                $scope.systemErrors = data.errors.systemError;
                                $scope.popupMessage = data.errors.systemError;
                                $('#myModal').modal('show');
                                $scope.message = false;
                            } else {
                                $scope.message = data.success.message;
                                $scope.systemErrors = false;
                                $scope.popupMessage = data.success.popupMessage;
                                if (data.success.popupMessage) {
                                    $scope.level1 = data.success.level_1;
                                    $scope.level2 = data.success.level_2;
                                    $scope.level3 = data.success.level_3;
                                }
                                $('#myModal').modal('show');
                                $scope.isSaved = data.success.saved;
                                if (data.success.saved)
                                    $scope.resetForm();
                            }
                            loading(false);
                        });
            }
        }
    };
    $scope.resetForm = function () {
        $scope.workData = {};
        $scope.woForm.$setPristine();
    };
    $scope.get_workorder_view = function () {
        $('#myModal').modal('hide');
        if ($scope.isCompletedFlag)
            $location.path('/workorders');
        else if ($scope.isSaved)
            $location.path('/workorder/view/' + $scope.workorder_id + '/true');
    };
    $scope.checkZero = function () {
        if ($scope.workData.amount == "0.00" || $scope.workData.amount == "0") {
            $scope.workData.amount = "";
        }
    }
    $scope.checkZeroBlur = function () {
        if ($scope.workData.amount == "") {
            $scope.workData.amount = 0;
        }
    }
});

realestateApp.controller('invitationController', function ($scope, $http, $location, $rootScope) {
    action_btn($rootScope);
    $scope.loginData = {};
    $scope.workorder_id = 0;

    $scope.isHidden = true;

    $scope.workData = {};
    $scope.userData = {};

    $scope.buildings = [];
    $scope.workData.building;

    $scope.pendingInvitations = [];
    $scope.canceledInvitations = [];

    $scope.update_form = function () {
        if ($scope.workData.building == 0) {
            $scope.isHidden = true;
        } else {
            $scope.isHidden = false;
        }
    }
    $scope.init = function () {
        toggle_left_sidebar();
        console.log(1);
        $http({
            method: 'POST',
            url: get_base_url() + '/validate_user',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })
                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                        if ($rootScope.appInitFlag)
                            login();
                    } else {
                        $scope.unseen_noti = data.success.unseen_noti;
                        if (data.success.data.user_type == 0) {
                            $location.path('/dashboard');
                        } else {
                            $rootScope.isSecured = true;
                            //$scope.message = data.success.message;
                            $scope.userData = data.success.data;
                            $scope.systemErrors = false;
                            $scope.isSecured = true;
                            $scope.loadBuildings();
                        }
                    }
                });
    };
    $scope.loadPendingList = function () {
        loading();
        $http({
            method: 'POST',
            data: $.param($scope.workData.building),
            url: get_base_url() + '/invitations/get_pending_list',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.pendingInvitations = [];
                        $scope.message = false;
                    } else {
                        $scope.pendingInvitations = data.success.data;
                        $scope.systemErrors = false;
                    }
                    loading();
                });
    };
    $scope.loadCanceledList = function () {
        loading();
        $http({
            method: 'POST',
            data: $.param($scope.workData.building),
            url: get_base_url() + '/invitations/get_canceled_list',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.canceledInvitations = [];
                        $scope.message = false;
                    } else {
                        $scope.canceledInvitations = data.success.data;
                        $scope.systemErrors = false;
                    }
                    loading();
                });
    };
    $scope.loadBuildings = function () {
        $http({
            method: 'POST',
            url: get_base_url() + '/workorder/buildings',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                        $scope.buildings = [];
                    } else {
                        $scope.buildings = data.success.data;
                        $scope.systemErrors = false;
                    }
                });
    };
    $scope.send_inv = function (isValid) {
        if (isValid) {
            loading(true);
            $http({
                method: 'POST',
                data: $.param($scope.workData),
                url: get_base_url() + '/invitations/send',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            })

                    .success(function (data) {
                        if (!data.success) {
                            $scope.systemErrors = data.errors.systemError;
                            $scope.message = false;
                        } else {
                            $scope.message = data.success.message;
                            $scope.systemErrors = false;
                            $scope.resetForm();
                        }
                        loading(false);
                    });
        } else {
            $scope.$broadcast('kickOffValidations');
        }
    };

    $scope.resend = function (id) {
        if (id != null && id != 0) {
            $scope.tempResend = {id: id};
            $http({
                method: 'POST',
                data: $.param($scope.tempResend),
                url: get_base_url() + '/invitations/resend',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            })

                    .success(function (data) {
                        if (!data.success) {
                            $scope.systemErrors = data.errors.systemError;
                            $scope.message = false;
                        } else {
                            $('#resend_btn_' + id).html('<button class="btn btn-xs disabled btn-gray" style="margin-top: -20px;padding: 0px;">Sent</button>');
                        }
                    });
        } else {
            $scope.$broadcast('kickOffValidations');
        }
    };

    $scope.updateRole = function ($event, id) {
        var checkbox = $event.target;
        var action = (checkbox.checked ? 1 : 0);
        $scope.temp_data = {id: id, type: "role", val: action};
        $http({
            method: 'POST',
            data: $.param($scope.temp_data),
            url: get_base_url() + '/invitations/updateRole',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                    } else {
                        $scope.responseMessage = data.success.message;
                        $scope.systemErrors = false;
                    }
                });
    };

    $scope.updateCanceled = function ($event, id) {
        var checkbox = $event.target;
        var action = (checkbox.checked ? 1 : 0);
        $scope.temp_data = {id: id, type: "cancel", val: action};
        $http({
            method: 'POST',
            data: $.param($scope.temp_data),
            url: get_base_url() + '/invitations/updateCanceled',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                    } else {
                        $scope.responseMessage = data.success.message;
                        $scope.systemErrors = false;
                    }
                });
    };

    $scope.removeSpace = function () {
        if ($scope.workData.tenants) {
            var temp = $scope.workData.tenants;
            temp = temp.replace(/ +(?= )/g, '');
            $scope.workData.tenants = temp.replace(/\n+(?=\r\n|\n|\r)/gm, "");
        }
        if ($scope.workData.managers) {
            var temp = $scope.workData.managers;
            temp = temp.replace(/ +(?= )/g, '');
            $scope.workData.managers = temp.replace(/\n+(?=\r\n|\n|\r)/gm, "");
        }
    }
    $scope.resetForm = function () {
        $scope.isHidden = true;
        $scope.workData = {};
        $scope.invForm.$setPristine();
    };

    $scope.renderHtml = function (htmlCode) {
        return $sce.trustAsHtml(htmlCode);
    };
});

realestateApp.controller('registerController', function ($scope, $http, $stateParams, $location, $rootScope) {
    $rootScope.act_btn_isHidden = true;
    $rootScope.bottom_menu_isHidden = true;
    $scope.invData = {refID: $stateParams.refID, iisSameFirstName: false};
    $scope.isDisabled = false;
    $scope.isManager = false;
    $scope.isCompanyName = false;
    $('body').addClass('login-layout');
    $('.sidebar').addClass('cl_hide');
    $('.navbar').addClass('cl_hide');
    $('.main-content').css('margin', '0px');
    $scope.init = function () {
        toggle_left_sidebar();
        $scope.simple_logout();
        $http({
            method: 'POST',
            url: get_base_url() + '/invitations/get_invitation',
            data: $.param($scope.invData),
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                        $scope.invalidInvitation = true;
                    } else {
                        if (data.success.data.role == 1) {
                            $scope.isManager = true;
                        }
                        //$scope.message = data.success.message;
                        $scope.building_name = data.success.data.building_name;
                        $scope.invData.email = data.success.data.email;
                        $scope.invData.nemail = data.success.data.email;
                        $scope.invData.id = data.success.data.id;
                        $scope.systemErrors = false;
                    }
                });
    };

    $scope.simple_logout = function () {
        $http({
            method: 'POST',
            url: get_base_url() + "/logout",
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })
                .success(function (data) {
                    //$location.path('/login');
                });
    };
    $scope.verify_invitation = function (isValid) {
        if (isValid) {
            $scope.isDisabled = true;
            $http({
                method: 'POST',
                url: get_base_url() + '/invitations/verify_invitation',
                data: $.param($scope.invData),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            })

                    .success(function (data) {
                        if (!data.success) {
                            //$scope.systemErrors = "Your invitation to "+$scope.building_name+" was canceled. Please contact the landlord and ask them to invite you again, if you believe this is a mistake.";
                            $scope.systemErrors = data.errors.systemError;
                            $scope.isDisabled = false;
                        } else {
                            $scope.isCompanyName = data.success.company_name;
                            if (data.success.data.registered) {
                                $location.path('/login/' + $scope.invData.refID);
                            } else {
                                switch_to("#signup-box");
                                $scope.code_required = data.success.code_required;
                                ;
                            }
                        }
                    });
        }
    };

    $scope.update_comp_name = function () {
        if ($scope.invData.isSameFirstName)
            $scope.invData.comp_name = $scope.invData.first_name + " " + $scope.invData.last_name;
        else
            $scope.invData.comp_name = "";
    };

    $scope.join_building = function (isValid) {
        if ($scope.invData.tos_pp) {
            if (isValid) {
                loading(true);
                $scope.isDisabled = true;
                $http({
                    method: 'POST',
                    url: get_base_url() + '/invitations/join_building',
                    data: $.param($scope.invData),
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'}
                })

                        .success(function (data) {
                            if (!data.success) {
                                //$scope.systemErrors = "Your invitation to "+$scope.building_name+" was canceled. Please contact the landlord and ask them to invite you again, if you believe this is a mistake.";
                                $scope.systemErrors2 = data.errors.systemError;
                                $scope.isDisabled = false;
                                $('html, body').animate({scrollTop: '0px'}, 0);
                            } else {
                                if (data.success.data.registered) {
                                    $location.path('/login/' + $scope.invData.refID);
                                }
                                $scope.message2 = data.success.message;
                                $scope.systemErrors2 = false;
                                if (data.success.data.redirect) {
                                    $location.path(data.success.data.redirect);
                                }
                            }
                            loading(false);
                        });
            }
        } else {
            $scope.tos_pp_msg = "You must agree with the Terms of Service and Privacy Policy.";
        }
    };
});

realestateApp.controller('joinBuildingController', function ($scope, $http, $stateParams, $location, $rootScope, $i18next) {
    $rootScope.act_btn_isHidden = true;
    $rootScope.bottom_menu_isHidden = true;
    $('body').addClass('login-layout');
    $('.sidebar').addClass('cl_hide');
    $('.navbar').addClass('cl_hide');
    $('.main-content').css('margin', '0px');
    $scope.invData = {refID: $stateParams.refID, isSameFirstName: false};
    $scope.isDisabled = false;
    $scope.isCompanyName = false;
    $scope.isManager = false;
    $scope.redirectURI = "login.html";
    $scope.init = function () {
        toggle_left_sidebar();
        console.log(1);
        $http({
            method: 'POST',
            url: get_base_url() + '/validate_user',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                    } else {
                        $scope.get_invitation();
                        $scope.systemErrors = false;
                    }
                });
    };

    $scope.get_invitation = function () {
        $http({
            method: 'POST',
            url: get_base_url() + '/invitations/get_invitation_s',
            data: $.param($scope.invData),
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        $scope.systemErrors = data.errors.systemError;
                        $scope.message = false;
                    } else {
                        if (data.success.data.role == 1) {
                            $scope.isManager = true;
                        }
                        //$scope.message = data.success.message;
                        $scope.isCompanyName = data.success.company_name;
                        $scope.building_name = data.success.data.building_name;
                        $scope.invData.email = data.success.data.email;
                        $scope.invData.id = data.success.data.id;
                        $scope.invData.name = data.success.data.name;
                        $scope.systemErrors = false;
                    }
                });
    };

    $scope.update_comp_name = function () {
        if ($scope.invData.isSameFirstName)
            $scope.invData.comp_name = $scope.invData.name;
        else
            $scope.invData.comp_name = "";
    };

    $scope.join_building = function (isValid) {
        if (isValid) {
            loading(true);
            $scope.isDisabled = true;
            $http({
                method: 'POST',
                url: get_base_url() + '/invitations/join_building_s',
                data: $.param($scope.invData),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            })

                    .success(function (data) {
                        if (!data.success) {
                            //$scope.systemErrors = "Your invitation to "+$scope.building_name+" was canceled. Please contact the landlord and ask them to invite you again, if you believe this is a mistake.";
                            $scope.systemErrors = data.errors.systemError;
                            $scope.isDisabled = false;
                        } else {
                            $scope.message = data.success.message;
                            $scope.building_name = data.success.buildingName;
                            $scope.systemErrors = false;
                            if (data.success.data.redirect) {
                                $('#myModal').modal('show');
                                $scope.popupMessage = data.success.message;
                                $scope.redirectURI = data.success.data.redirect;
                            }
                        }
                        loading(false);
                    });
        }
    };

    $scope.get_redirect = function () {
        $location.path($scope.redirectURI);
    };

});

realestateApp.controller('gsettingsController', function ($scope, $http, $stateParams, $location, $rootScope, $i18next) {
    action_btn($rootScope);
    $scope.pageHeader = "General Settings";
    $scope.languages = [];
    $scope.init = function () {
        toggle_left_sidebar();
        console.log(1);
        $http({
            method: 'POST',
            url: get_base_url() + '/validate_user',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        if ($rootScope.appInitFlag) {
                            $rootScope.redirectURL = $location.path();
                            login();
                        }
                    } else {
                        $scope.unseen_noti = data.success.unseen_noti;
                        $scope.font_setting = angular.copy(data.success.font_setting);
                        $scope.load_Languages();
                        if (data.success.data.user_type == 1) {
                            $scope.isSecured = true;
                            $rootScope.isSecured = true;
                        }
                    }
                });
    };

    $scope.load_Languages = function () {
        $http({
            method: 'POST',
            url: get_base_url() + '/ln',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        })

                .success(function (data) {
                    if (!data.success) {
                        if ($rootScope.appInitFlag) {

                        }
                    } else {
                        $scope.languages = data.success.data;
                        if (data.success.ln) {
                            angular.forEach(data.success.data, function (value, key) {
                                if (value.id == data.success.ln.id) {
                                    $scope.ln = data.success.data[key];
                                }
                            });
                        }
                    }
                });
    };

    $scope.updateLngSetting = function (val) {
        if ($scope.font_setting != "") {
            $scope.temp = {val: val};
            $http({
                method: 'POST',
                url: get_base_url() + '/ln/update',
                data: $.param($scope.temp),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            })

                    .success(function (data) {
                        if (!data.success) {
                            $scope.message = false;
                            $scope.systemErrors = data.errors.systemError;
                        } else {
                            $scope.message = data.success.message;
                            $scope.systemErrors = false;
                        }
                    });
        }
    };

    $scope.updateSettings = function (val) {
        if ($scope.font_setting != "") {
            $scope.temp = {val: val};
            $http({
                method: 'POST',
                url: get_base_url() + '/settings/update_fontsize',
                data: $.param($scope.temp),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            })

                    .success(function (data) {
                        if (!data.success) {
                            $scope.message = false;
                            $scope.systemErrors = data.errors.systemError;
                        } else {
                            if (data.success.font_setting_css)
                                jQuery('#font-size-css').attr('href', 'theme/css/' + data.success.font_setting_css);
                            else
                                jQuery('#font-size-css').attr('href', '');
                            $scope.message = data.success.message;
                            $scope.systemErrors = false;
                        }
                    });
        }
    };

    $scope.changeLang = function () {
        if ($scope.ln.code === 'patrick') {
            $i18next.options.postProcess = 'patrick';
        } else {
            $i18next.options.postProcess = '';
            $i18next.options.lng = $scope.ln.code;
            $scope.updateLngSetting($scope.ln.id);
            console.log($i18next.debugMsg[$i18next.debugMsg.length - 1]);
        }
    };
});
function action_btn($rootScope) {
    console.log('action_btn: false');
    $rootScope.cameraBtn = false;
    $rootScope.receiptBtn = false;
    $rootScope.groupsBtn = false;
    var navigationContainer = $('#cd-nav'),
            mainNavigation = navigationContainer.find('#cd-main-nav ul');
    $("#cd-nav-trigger").removeClass('menu-is-open');
    mainNavigation.off('webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend').removeClass('is-visible');

    var navigationContainer = $('#act-btn-nav'),
            mainNavigation = navigationContainer.find('#cd-main-nav ul');
    //mainNavigation_hoz = navigationContainer.find('#ab-horizontal ul');

    $('.act-btn-trigger').removeClass('menu-is-open');
    mainNavigation.off('webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend').removeClass('is-visible');
    //mainNavigation_hoz.off('webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend').removeClass('is-visible');

    var navigationContainer = $('#menu2'),
            mainNavigation = navigationContainer.find('#menu2-nav ul');
    $('#cd-nav-trigger2').removeClass('menu-is-open');
    mainNavigation.off('webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend').removeClass('is-visible');

    $(".white_box").removeClass('cl_show');
}
